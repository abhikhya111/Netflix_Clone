const data = [
  { title: 'dashboards.pending-orders', icon: 'iconsminds-clock', value: 14 },
  {
    title: 'dashboards.completed-orders',
    icon: 'iconsminds-basket-coins',
    value: 32,
  },
  {
    title: 'dashboards.refund-requests',
    icon: 'iconsminds-arrow-refresh',
    value: 74,
  },
  { title: 'dashboards.new-comments', icon: 'iconsminds-mail-read', value: 25 },
];
export default data;
